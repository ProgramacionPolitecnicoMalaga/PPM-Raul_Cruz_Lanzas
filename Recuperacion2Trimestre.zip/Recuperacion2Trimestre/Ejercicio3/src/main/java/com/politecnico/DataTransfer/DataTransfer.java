package com.politecnico.DataTransfer;

public class DataTransfer {
    public String etiqueta;
    public String tipo;
    public String nombre;
    public String ip;
    public int coste;
}
