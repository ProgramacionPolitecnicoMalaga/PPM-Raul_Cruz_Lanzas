import Vista.Principal;

public class App {
    public static void main(String[] args) {
        Principal principal = new Principal();
        System.out.println(principal.Fibonacci(10, 8));
    }
}
