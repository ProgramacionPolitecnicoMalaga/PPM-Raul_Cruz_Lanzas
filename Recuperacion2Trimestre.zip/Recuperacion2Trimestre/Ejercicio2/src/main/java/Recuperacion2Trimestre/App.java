package Recuperacion2Trimestre;

import Recuperacion2Trimestre.DAO.RackDAO;

import java.sql.SQLException;

public class App
{
    public static void main( String[] args ) throws SQLException {
        RackDAO rackDAO = new RackDAO();
    }
}
