package Strategy;

public class Intento5Default implements DeseoNiño {
    @Override
    public String intento(String deseo) {
        return "se va a un rincón a llorar";
    }
}
