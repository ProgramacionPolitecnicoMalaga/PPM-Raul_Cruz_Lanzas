package Strategy;

public class Intento4 implements DeseoNiño {
    @Override
    public String intento(String deseo) {
        return "llora y grita a un adulto ¡" + deseo + "!";
    }
}
