package Strategy;

public class Intento3 implements DeseoNiño {

    @Override
    public String intento(String deseo) {
        return "pone cara de pena y decir a un adulto " + deseo;
    }
}
