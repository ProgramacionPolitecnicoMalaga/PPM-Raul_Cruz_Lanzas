package Strategy;

public interface DeseoNiño {
    int Intento1 = 1;
    int Intento2 = 2;
    int Intento3 = 3;
    int Intento4 = 4;
    int Intento5Default = 5;

    public String intento(String deseo);
}
