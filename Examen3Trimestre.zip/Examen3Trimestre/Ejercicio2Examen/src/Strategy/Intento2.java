package Strategy;

public class Intento2 implements DeseoNiño {
    @Override
    public String intento(String deseo) {
        return "dice a un adulto: ¡Quiero " + deseo + "!";
    }
}
