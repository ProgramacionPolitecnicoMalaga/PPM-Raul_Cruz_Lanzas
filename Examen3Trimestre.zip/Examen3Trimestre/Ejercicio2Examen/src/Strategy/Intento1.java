package Strategy;

public class Intento1 implements DeseoNiño{
    @Override
    public String intento(String deseo) {
        return "intenta coger " + deseo + " sin que le vean";
    }
}
